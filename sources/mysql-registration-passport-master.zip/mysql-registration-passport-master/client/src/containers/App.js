import React from 'react';
import './App.css';
import Routes from '../Routes';

const App = () => (
  <div className="App">
    <Routes />
  </div>
);

export default App;
