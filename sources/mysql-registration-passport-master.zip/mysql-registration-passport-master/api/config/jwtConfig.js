module.exports = {
  secret: 'jwt-secret',
};
